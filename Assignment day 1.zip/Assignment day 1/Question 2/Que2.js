let minutes = 10;
let seconds = minutes * 60;
console.log("Seconds of 10 min are:"+seconds);