let array = ["pen","pencil","book","scale","eraser"]

var found = array.find(function (element) 
{ 
    return element == "book"; 
});
console.log(found);
 
var index= array.indexOf("book");

console.log(index);