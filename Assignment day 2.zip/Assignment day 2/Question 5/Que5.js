let array = [5,4,8,9,10,12]

let print = array.reverse();

console.log(print);