let name = "Mrunal Rajeev Mandhare";
var character = name.search("R");
console.log(character);