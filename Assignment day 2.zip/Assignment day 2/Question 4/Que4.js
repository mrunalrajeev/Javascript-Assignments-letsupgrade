let array = ["pen","pencil","book","scale","eraser"]

let i = array.indexOf();


for (i = 0; i < array.length ; i++) 
{
    if(array[i].includes('a'))
    console.log(array[i]);
    
}


